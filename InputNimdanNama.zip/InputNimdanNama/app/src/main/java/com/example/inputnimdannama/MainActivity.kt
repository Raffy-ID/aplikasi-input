package com.example.inputnimdannama

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtNama = findViewById<EditText>(R.id.edtNama)
        val edtNIM = findViewById<EditText>(R.id.edtNIM)
        val tvHasil = findViewById<TextView>(R.id.tvHasil)
        val btnSubmit = findViewById<Button>(R.id.btnSubmit)

        btnSubmit.setOnClickListener {
            tvHasil.setText("Nama & NIM Anda: " + edtNama.text + " & " + edtNIM.text)
            }
        }
    }